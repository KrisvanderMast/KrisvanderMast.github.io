﻿using System;

namespace MVC2LoadPartialViewThroughAjax.Models
{
    public class Product
    {
        public String Name { get; set; }

        public Decimal Price { get; set; }

        public String Category { get; set; }

        public override string ToString()
        {
            return String.Format("Name: {0}; Price: {1}; Category: {2}", Name, Price, Category);
        }
    }
}