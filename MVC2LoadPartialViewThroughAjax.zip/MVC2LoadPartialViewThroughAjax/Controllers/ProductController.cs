﻿using System;
using System.Web.Mvc;
using MVC2LoadPartialViewThroughAjax.Models;
using System.Threading;

namespace MVC2LoadPartialViewThroughAjax.Controllers
{
    public class ProductController : Controller
    {
        //
        // GET: /Product/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Edit()
        {
            Product product = new Product()
            {
                Name = "Crispy crazy",
                Price = 3.17m,
                Category = "Sushi"
            };

            // Bad practice but just to show the animation in the right upper corner...
            Thread.Sleep(3000);

            return PartialView(product);
        }

        [HttpPost]
        public ContentResult Edit(Product product)
        {
            Product p = product;

            return Content(String.Format("Adjusted product: {0}", p.ToString()));
        }
    }
}
